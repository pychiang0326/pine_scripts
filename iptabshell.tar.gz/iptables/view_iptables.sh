#!/bin/bash

# 觀看現在iptables的設定
iptables -L -n -v
